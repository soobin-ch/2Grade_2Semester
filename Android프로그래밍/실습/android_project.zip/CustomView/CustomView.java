package com.example.customview;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

public class CustomView extends View {

    // 1. 코드로 뷰를 생성할 때 호출되는 생성자
    public CustomView(Context context) {
        super(context);
        setBackgroundColor(Color.YELLOW);
    }

    // 2. XML 레이아웃에서 뷰를 참조할 때 반드시 구현해야 하는 생성자
    public CustomView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setBackgroundColor(Color.YELLOW);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColor(Color.RED);

        // 원호를 그리는 부분:
        // drawArc(RectF bounds, float startAngle, float sweepAngle, boolean useCenter, Paint paint)
        canvas.drawArc(new RectF(10, 10, 600, 600), 45, 320, true, paint);
    }
}