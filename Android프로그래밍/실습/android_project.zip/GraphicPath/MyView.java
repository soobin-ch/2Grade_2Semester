package com.example.graphicpath;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

class MyView extends View {

    public MyView(Context context) {
        super(context);
        setBackgroundColor(Color.YELLOW);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        // 1. Path와 Paint 객체 생성
        Path path = new Path();
        Paint paint = new Paint();

        // 2. 경로(Path) 정의
        // 경로를 그리는 스타일은 STROKE로 설정
        paint.setStyle(Paint.Style.STROKE);

        // 시작점 이동: (x: 20, y: 400)
        path.moveTo( 20,  400);

        // 직선 추가: (x: 300, y: 800)까지 직선으로 연결
        path.lineTo(300, 800);

        // 3차 베지어 곡선 추가:
        // 제어점 1 (x1: 450, y1: 120), 제어점 2 (x2: 600, y2: 1200)을 사용하여
        // 끝점 (x3: 900, y3: 800)까지 곡선을 그림
        path.cubicTo( 450,  120,600,  1200, 900, 800);

        // 3. 정의된 경로 자체를 화면에 그리기
        paint.setColor(Color.BLUE);
        canvas.drawPath(path, paint);

        // 4. 경로 위에 텍스트 그리기 설정을 위한 Paint 스타일 변경
        paint.setStyle(Paint.Style.FILL); // 텍스트를 채워 그리기 위해 FILL로 변경
        paint.setTextSize(200);           // 텍스트 크기 설정

        // 5. 경로를 따라 텍스트 그리기
        // "This is a test!!" 텍스트를 위에서 정의한 'path'를 따라 그림
        // hOffset(수평 오프셋): 0, vOffset(수직 오프셋): 0
        canvas.drawTextOnPath("This is a test!!", path,  0, 0, paint);
    }
}