package com.example.graphicbitmap;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.graphicbitmap.databinding.ActivityMainBinding;

class MyView extends View {

    public MyView(Context context) {
        super(context);
        // 뷰의 배경색을 노란색으로 설정합니다.
        setBackgroundColor(Color.YELLOW);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Paint paint = new Paint();

        Matrix m = new Matrix();
        // m.preScale(sx, sy) : x축 방향 1배 (변화 없음), y축 방향 -1배 (상하 반전)
        m.preScale(1, -1);

        // 2. 리소스에서 원본 비트맵 로드
        Bitmap b = BitmapFactory.decodeResource(getResources(), R.drawable.house);

        // 3. 상하 반전된 비트맵 생성 (mb)
        // Bitmap.createBitmap(원본, x좌표, y좌표, 너비, 높이, 변환행렬, 필터링 여부)
        Bitmap mb = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, false);

        // 4. 크기가 조절된 비트맵 생성 (sb)
        // Bitmap.createScaledBitmap(원본, 새 너비(600), 새 높이(600), 필터링 여부)
        Bitmap sb = Bitmap.createScaledBitmap(b, 600, 600, false);

        // 5. 상하 반전된 비트맵(mb)을 (0, 0) 위치에 그리기
        canvas.drawBitmap(mb, 0, 0, null);

        // 6. 크기가 조절된 비트맵(sb)을 (100, 100) 위치에 그리기
        canvas.drawBitmap(sb, 100, 100, null);
    }
}

// 메인 액티비티: 커스텀 뷰를 화면에 표시합니다.
public class MainActivity extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // MyView 객체를 생성하여 액티비티의 내용으로 설정합니다.
        MyView w = new MyView(this);
        setContentView(w);
    }
}