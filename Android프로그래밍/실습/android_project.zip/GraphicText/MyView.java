package com.example.graphictext;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

class MyView extends View {
    private Paint mPaints, mFramePaint;
    private RectF mBigOval;
    private float mStart, mSweep;

    // 애니메이션 속도 제어 상수
    private static final float SWEEP_INC = 2; // 쓸기 각도 증가량
    private static final float START_INC = 15; // 시작 각도 증가량

    // 생성자: View 초기화 및 Paint 객체 설정 (시간이 오래 걸리는 작업 미리 수행)
    public MyView(Context context) {
        super(context);

        // 1. mPaints (원호 채우기용) 설정: FILL 스타일, 빨간색
        mPaints = new Paint();
        mPaints.setAntiAlias(true);
        mPaints.setStyle(Paint.Style.FILL);
        mPaints.setColor(0x88FF0000); // 반투명 빨간색 (ARGB)

        // 2. mFramePaint (프레임 그리기용) 설정: STROKE 스타일, 녹색, 선 폭 3 픽셀
        mFramePaint = new Paint();
        mFramePaint.setAntiAlias(true);
        mFramePaint.setStyle(Paint.Style.STROKE);
        mFramePaint.setStrokeWidth(3);
        mFramePaint.setColor(0x8800FF00); // 반투명 녹색 (ARGB)

        // 3. 원호가 그려질 영역 정의 (RectF(좌, 상, 우, 하))
        mBigOval = new RectF(40, 10, 900, 1000);
    }

    // 화면을 그리는 메서드

    @Override
    protected void onDraw(Canvas canvas) {
        // 1. Paint 객체 생성 및 기본 설정
        Paint paint = new Paint();
        paint.setAntiAlias(true); // 앤티앨리어싱 설정 (글꼴의 계단 현상 완화)
        paint.setTextSize(100);   // 폰트 크기 설정

        // 2. DEFAULT 폰트 (일반 스타일) 그리기
        Typeface t;
        // Typeface.DEFAULT (기본 폰트), Typeface.NORMAL (일반 스타일)
        t = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL);
        paint.setTypeface(t);
        // 텍스트, X좌표 (10), Y좌표 (200), Paint 객체
        canvas.drawText("DEFAULT 폰트", 10, 200, paint);

        // 3. SERIF 폰트 (이탤릭 스타일) 그리기
        // Typeface.SERIF (Serif 폰트 계열), Typeface.ITALIC (이탤릭 스타일)
        t = Typeface.create(Typeface.SERIF, Typeface.ITALIC);
        paint.setTypeface(t);
        // 텍스트, X좌표 (10), Y좌표 (300), Paint 객체
        canvas.drawText("SERIF 폰트", 10, 300, paint);

        // 4. SANS_SERIF 폰트 (볼드 이탤릭 스타일) 그리기
        // Typeface.SANS_SERIF (Sans-Serif 폰트 계열), Typeface.BOLD_ITALIC (볼드 이탤릭 스타일)
        t = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD_ITALIC);
        paint.setTypeface(t);
        // 텍스트, X좌표 (10), Y좌표 (400), Paint 객체
        canvas.drawText("SANS_SERIF 폰트", 10, 400, paint);
    }
}