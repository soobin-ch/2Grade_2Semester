package com.example.myphotoshop;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.myphotoshop.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    float scaleX = 1.0f, scaleY = 1.0f, rotateAngle;
    MyView displayView;

    public class MyView extends View {
        public MyView(MainActivity context) {
            super(context);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            Paint paint = new Paint();

            // 비트맵을 화면 중앙에 그린다.
            @SuppressLint("DrawAllocation") Bitmap picture = BitmapFactory.decodeResource(getResources(),
                    R.drawable.lena);

            int centerX = getWidth() / 2;
            int centerY = getHeight() / 2;

            // 현재 설정된 축척과 회전각으로 비트맵을 화면에 그린다.
            canvas.scale(scaleX, scaleY, centerX, centerY);
            canvas.rotate(rotateAngle, centerX, centerY);

            canvas.drawBitmap(picture, 0, 0, paint);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 레이아웃에서 선형 레이아웃을 찾아서, 거기에 커스텀 뷰를 추가한다.
        LinearLayout layout = (LinearLayout) findViewById(R.id.imageDisplay);
        displayView = new MyView(this);
        layout.addView(displayView);
    }

    public void expand(View view) {
        scaleX += 0.3;
        scaleY += 0.3;
        displayView.invalidate();
    }

    public void shrink(View view) {
        // 그림을 축소해서 그린다.
        scaleX -= 0.3;
        scaleY -= 0.3;
        displayView.invalidate();
    }

    public void rotateLeft(View view) {
        // 그림을 왼쪽으로 회전시켜 그린다.
        rotateAngle -= 30;
        displayView.invalidate();
    }

    public void rotateRight(View view) {
        rotateAngle += 30;
        displayView.invalidate();
    }
}