package com.example.graphicfont;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.View;

public class MyView extends View {

    public MyView(Context context) {
        super(context);
        setBackgroundColor(Color.YELLOW);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Typeface myFont;
        Paint paint = new Paint();

        // 1. Paint 객체 기본 설정
        paint.setAntiAlias(true);

        // 2. Assets 폴더에서 폰트 파일 로드
        // "animeace2_ital.ttf" 파일을 Assets 폴더에서 찾아 Typeface 객체로 생성합니다.
        myFont = Typeface.createFromAsset(getContext().getAssets(),
                "animeace2_ital.ttf");

        // 3. 폰트 및 크기 설정
        paint.setTypeface(myFont);
        paint.setTextSize(80);

        // 4. 텍스트 그리기
        // X=10, Y=400 위치에 텍스트 그리기
        canvas.drawText( "This is a New Font!!!", 10, 400, paint);

        // X=10, Y=800 위치에 텍스트 그리기
        canvas.drawText( "Have Fun!!!", 10, 800, paint);
    }
}