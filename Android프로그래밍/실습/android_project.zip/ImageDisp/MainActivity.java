package com.example.imagedisp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.imagedisp.databinding.ActivityMainBinding;

class MyView extends View {

    public MyView(Context context) {
        super(context);
        // 뷰의 배경색을 노란색으로 설정합니다.
        setBackgroundColor(Color.YELLOW);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Paint paint = new Paint();

        // 1. 리소스에서 이미지를 읽어 비트맵으로 디코딩합니다.
        // R.drawable.cat은 res/drawable 폴더의 'cat' 리소스를 참조해야 합니다.
        @SuppressLint("DrawAllocation") Bitmap b = BitmapFactory.decodeResource(getResources(),
                R.drawable.cat);

        // 2. 비트맵을 캔버스의 (0, 0) 좌표에 그립니다.
        // null은 별도의 Paint 효과(변형 등)를 지정하지 않음을 의미합니다.
        canvas.drawBitmap(b, 0, 0, null);
    }
}

// 메인 액티비티: 커스텀 뷰를 화면에 표시합니다.
public class MainActivity extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // MyView 객체를 생성하여 액티비티의 내용으로 설정합니다.
        MyView w = new MyView(this);
        setContentView(w);
    }
}