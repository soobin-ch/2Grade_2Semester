package com.example.myarc;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

class MyView extends View {
    private Paint mPaints, mFramePaint;
    private RectF mBigOval;
    private float mStart, mSweep;

    // 애니메이션 속도 제어 상수
    private static final float SWEEP_INC = 2; // 쓸기 각도 증가량
    private static final float START_INC = 15; // 시작 각도 증가량

    // 생성자: View 초기화 및 Paint 객체 설정 (시간이 오래 걸리는 작업 미리 수행)
    public MyView(Context context) {
        super(context);

        // 1. mPaints (원호 채우기용) 설정: FILL 스타일, 빨간색
        mPaints = new Paint();
        mPaints.setAntiAlias(true);
        mPaints.setStyle(Paint.Style.FILL);
        mPaints.setColor(0x88FF0000); // 반투명 빨간색 (ARGB)

        // 2. mFramePaint (프레임 그리기용) 설정: STROKE 스타일, 녹색, 선 폭 3 픽셀
        mFramePaint = new Paint();
        mFramePaint.setAntiAlias(true);
        mFramePaint.setStyle(Paint.Style.STROKE);
        mFramePaint.setStrokeWidth(3);
        mFramePaint.setColor(0x8800FF00); // 반투명 녹색 (ARGB)

        // 3. 원호가 그려질 영역 정의 (RectF(좌, 상, 우, 하))
        mBigOval = new RectF(40, 10, 900, 1000);
    }

    // 화면을 그리는 메서드
    @Override
    protected void onDraw(Canvas canvas) {
        // 1. 배경을 노란색으로 칠함
        canvas.drawColor(Color.YELLOW);

        // 2. 원호 영역의 사각형 프레임을 녹색으로 그림
        canvas.drawRect(mBigOval, mFramePaint);

        // 3. 현재 각도(mStart)에서 쓸기 각도(mSweep)만큼의 원호를 빨간색으로 그림
        // 'false'는 중심을 포함하지 않아 부채꼴(pie)이 아닌 원호(arc)를 그림을 의미합니다.
        canvas.drawArc(mBigOval, mStart, mSweep, false, mPaints);

        // 4. 쓸기 각도(mSweep)를 증가시키고 360도를 넘으면 리셋 및 시작 각도 조정
        mSweep += SWEEP_INC;
        if (mSweep > 360) {
            mSweep -= 360;

            // 쓸기 각도가 한 바퀴 돌 때마다 시작 각도(mStart)를 증가시킴
            mStart += START_INC;
            if (mStart >= 360) {
                mStart -= 360;
            }
        }

        // 5. 뷰를 무효화하여 onDraw() 메서드가 다시 호출되게 함 (애니메이션 루프)
        invalidate();
    }
}