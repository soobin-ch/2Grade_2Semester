package com.example.buttonevent2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = (Button) findViewById(R.id.button);

        // 익명 내부 클래스를 사용하여 리스너 설정
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 클릭 시 "버튼이 눌러졌습니다" 토스트 메시지를 보여줌
                Toast.makeText(getApplicationContext(),
                        "버튼이 눌러졌습니다", Toast.LENGTH_SHORT).show();
            }
        });
    }
}