package com.example.buttonevent3;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = (Button) findViewById(R.id.button);

        // 람다 표현식을 사용하여 리스너 설정
        button.setOnClickListener((v) -> {
            Toast.makeText(getApplicationContext(),
                    "버튼이 눌러졌습니다", Toast.LENGTH_SHORT).show();
        });
    }
}