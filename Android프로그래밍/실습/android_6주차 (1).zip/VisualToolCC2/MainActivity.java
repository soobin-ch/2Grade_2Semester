package com.example.visualtoolcc2;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private List<Button> buttons = new ArrayList<>();
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // XML의 ID를 이용해 버튼들을 찾아 리스트에 추가합니다.
        buttons.add(findViewById(R.id.top_button));
        buttons.add(findViewById(R.id.left_button));
        buttons.add(findViewById(R.id.right_button_1));
        buttons.add(findViewById(R.id.right_button_2));
        buttons.add(findViewById(R.id.right_button_3));

        // 모든 버튼에 클릭 리스너를 설정합니다.
        for (Button button : buttons) {
            button.setOnClickListener(this);
        }
    }

    // 버튼 클릭 시 호출됩니다.
    @Override
    public void onClick(View view) {
        if (view instanceof Button) {
            Button clickedButton = (Button) view;

            // 랜덤 RGB 값을 생성합니다.
            int red = random.nextInt(256);
            int green = random.nextInt(256);
            int blue = random.nextInt(256);
            int randomColor = Color.rgb(red, green, blue);

            // 클릭된 버튼의 배경색을 변경합니다.
            clickedButton.setBackgroundTintList(ColorStateList.valueOf(randomColor));
        }
    }
}