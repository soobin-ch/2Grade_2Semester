package com.example.drawableanimation;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // 애니메이션 객체를 제어할 변수 선언
    AnimationDrawable rocketAnimation;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 레이아웃의 ImageView를 가져옵니다.
        ImageView rocketImage = (ImageView) findViewById(R.id.rocket_image);

        // 1번에서 만든 rocket.xml을 이미지뷰의 배경 리소스로 설정합니다.
        rocketImage.setBackgroundResource(R.drawable.rocket); //

        // 이미지뷰의 배경(AnimationDrawable) 객체를 가져옵니다.
        rocketAnimation = (AnimationDrawable) rocketImage.getBackground(); //
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // 화면을 터치했을 때(ACTION_DOWN) 애니메이션을 시작합니다.
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            rocketAnimation.start(); //
            return true;
        }
        return super.onTouchEvent(event);
    }
}