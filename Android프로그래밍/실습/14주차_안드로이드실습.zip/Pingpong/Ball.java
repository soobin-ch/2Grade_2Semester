package com.example.pingpong;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import java.util.Random;

// 움직이는 공을 나타내는 클래스
public class Ball {
    // x, y: 현재 위치, xInc, yInc: 한 번에 움직이는 거리 (속도)
    int x, y, xInc = 1, yInc = 1;
    int diameter; // 공의 반지름

    // WIDTH, HEIGHT: 공이 움직이는 공간의 크기 (화면 크기)
    static int WIDTH = 1080, HEIGHT = 1920;

    Paint paint;
    Random random = new Random();

    // 생성자
    public Ball(int d) {
        this.diameter = d;

        // 공의 위치를 랜덤하게 설정
        x = (int) (Math.random() * (WIDTH - d) + 3);
        y = (int) (Math.random() * (HEIGHT - d) + 3);

        // 한 번에 움직이는 거리를 랜덤하게 설정 (1에서 30 사이)
        xInc = (int) (Math.random() * 30 + 1);
        yInc = (int) (Math.random() * 30 + 1);

        paint = new Paint();

        // 랜덤 색상 설정 (ARGB)
        int color = Color.argb(255, random.nextInt(256), random.nextInt(256), random.nextInt(256));
        paint.setColor(color);
    }

    // 여기서 공을 그린다. (SurfaceView의 스레드에서 호출됨)
    public void paint(Canvas g) {
        // 벽이 부딪치면 반사하게 한다.
        if (x < diameter || x > (WIDTH - diameter))
            xInc = -xInc;
        if (y < diameter || y > (HEIGHT - diameter))
            yInc = -yInc;

        // 공의 좌표를 갱신한다.
        x += xInc;
        y += yInc;

        // 공을 화면에 그린다.
        g.drawCircle(x, y, diameter, paint);
    }
}