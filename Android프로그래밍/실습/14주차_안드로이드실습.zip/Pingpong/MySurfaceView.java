package com.example.pingpong;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class MySurfaceView extends SurfaceView implements SurfaceHolder.Callback {

    final int BALL_COUNT = 20; // 공의 개수
    public Ball basket[] = new Ball[BALL_COUNT]; // Ball의 배열
    private MyThread thread; // 스레드 참조 변수

    // 생성자
    public MySurfaceView(Context context) { this(context, null); }
    public MySurfaceView(Context context, AttributeSet attrs) {
        super(context, attrs);

        SurfaceHolder holder = getHolder(); // 서피스 뷰의 홀더를 얻는다.
        holder.addCallback(this); // 콜백 메서드를 처리한다.

        thread = new MyThread(holder); // 스레드를 생성한다.

        // Ball 객체를 생성하여 배열에 넣는다.
        for (int i = 0; i < BALL_COUNT; i++) {
            basket[i] = new Ball(100);
        }
    }

    // SurfaceHolder.Callback 구현

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        // 스레드를 시작한다.
        thread.setRunning(true);
        thread.start();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        // 스레드를 중지시킨다.
        boolean retry = true;
        thread.setRunning(false);
        while (retry) {
            try {
                thread.join(); // 메인 스레드와 합친다.
                retry = false;
            } catch (InterruptedException e) {
                // 예외 발생 시 다시 시도
            }
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        // 이 예제에서는 별도 처리 없음
    }


    public class MyThread extends Thread {

        private boolean mRun = false;
        private SurfaceHolder mSurfaceHolder;

        public MyThread(SurfaceHolder surfaceHolder) {
            mSurfaceHolder = surfaceHolder;
        }

        public void setRunning(boolean b) {
            mRun = b;
        }

        @Override
        public void run() {
            while (mRun) {
                Canvas c = null;
                try {
                    c = mSurfaceHolder.lockCanvas(null); // 캔버스를 잠근다.
                    synchronized (mSurfaceHolder) {
                        c.drawColor(Color.BLACK); // 캔버스의 배경을 지운다.

                        // basket의 모든 원소를 그린다.
                        for (Ball b : basket) {
                            b.paint(c);
                        }
                    }
                } finally {
                    // c != null 일 때 캔버스의 잠금을 푼다.
                    if (c != null) {
                        mSurfaceHolder.unlockCanvasAndPost(c);
                    }
                }
            }
        }
    }
}