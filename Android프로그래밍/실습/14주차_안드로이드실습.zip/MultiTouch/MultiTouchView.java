package com.example.multitouch;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class MultiTouchView extends View {

    private static final int SIZE = 60; // 그려질 원의 크기
    final int MAX_POINTS = 10; // 동시에 인식할 최대 손가락 개수

    // 각 터치 포인트의 좌표와 터치 여부를 저장할 배열
    float[] x = new float[MAX_POINTS];
    float[] y = new float[MAX_POINTS];
    boolean[] touching = new boolean[MAX_POINTS];

    private Paint mPaint;

    // 생성자
    public MultiTouchView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    // 코드에서 동적으로 생성할 때 사용되는 생성자
    public MultiTouchView(Context context) {
        super(context);
        initView();
    }

    private void initView() {
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setColor(Color.BLUE);
        mPaint.setStyle(Paint.Style.FILL_AND_STROKE);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int index = event.getActionIndex();       // 현재 이벤트가 발생한 포인터의 인덱스
        int id = event.getPointerId(index);       // 포인터의 고유 식별자(ID) 획득
        int action = event.getActionMasked();     // 액션 정보 획득 (멀티터치 처리를 위해 Masked 사용)

        switch (action) {
            case MotionEvent.ACTION_DOWN:         // 첫 번째 손가락 터치
            case MotionEvent.ACTION_POINTER_DOWN: // 두 번째 이상의 손가락 터치
                x[id] = (int) event.getX(index);
                y[id] = (int) event.getY(index);
                touching[id] = true;              // 해당 ID의 터치 상태 활성화
                break;

            case MotionEvent.ACTION_MOVE:         // 드래그 중
                // MOVE 이벤트는 모든 포인터에 대해 발생할 수 있으므로 반복문으로 처리하지 않고,
                // 여기서는 단순히 break 하거나 필요하다면 전체 포인터 위치를 갱신해야 합니다.
                // 이 예제 코드(이미지)에서는 MOVE 처리가 생략되어 있으나,
                // 실시간 이동을 보려면 아래와 같은 로직이 필요합니다.
                /*
                int pointerCount = event.getPointerCount();
                for(int i = 0; i < pointerCount; i++) {
                    int pointerId = event.getPointerId(i);
                    x[pointerId] = event.getX(i);
                    y[pointerId] = event.getY(i);
                }
                */
                break;

            case MotionEvent.ACTION_UP:           // 마지막 손가락 뗌
            case MotionEvent.ACTION_POINTER_UP:   // 여러 손가락 중 하나 뗌
            case MotionEvent.ACTION_CANCEL:       // 취소됨
                touching[id] = false;             // 해당 ID의 터치 상태 비활성화
                break;
        }

        invalidate(); // 화면 갱신 요청 (onDraw 호출)
        return true;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // 최대 포인트 개수만큼 반복하며 현재 터치 중인 곳에 원을 그립니다.
        for (int i = 0; i < MAX_POINTS; i++) {
            if (touching[i]) {
                canvas.drawCircle(x[i], y[i], SIZE, mPaint);
            }
        }
    }
}