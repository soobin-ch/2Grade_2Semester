package com.example.multitouch;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // XML 레이아웃 없이 MultiTouchView를 직접 생성하여 화면에 설정
        setContentView(new MultiTouchView(this, null));
    }
}