package com.example.customcomponent;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatImageView;

public class VolumeControlView extends AppCompatImageView {

    private double angle = 0.0;

    public VolumeControlView(Context context) {
        super(context);
        this.setImageResource(R.drawable.knob); // 'knob' 이미지가 drawable 폴더에 있어야 합니다.
    }

    public VolumeControlView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.setImageResource(R.drawable.knob);
    }

    // 터치 좌표(x, y)를 받아 뷰의 중심을 기준으로 각도를 계산하는 메서드
    public double getAngle(float x, float y) {
        float mx = x - (getWidth() / 2.0f);
        float my = (getHeight() / 2.0f) - y;

        // atan2를 이용해 각도를 계산하고 도(degree) 단위로 변환
        angle = Math.atan2(mx, my) * 180.0 / 3.141592;

        invalidate(); // 화면을 갱신하여 onDraw 호출
        return angle;
    }

    @Override
    protected void onDraw(Canvas c) {
        // 계산된 각도만큼 캔버스를 회전시킨 후 이미지를 그립니다.
        c.rotate((float) angle, getWidth() / 2, getHeight() / 2);
        super.onDraw(c);
    }
}