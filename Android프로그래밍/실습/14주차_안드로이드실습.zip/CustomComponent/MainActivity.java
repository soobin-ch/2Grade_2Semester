package com.example.customcomponent;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RatingBar;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnTouchListener {

    VolumeControlView vcv;
    RatingBar ratingbar;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        vcv = (VolumeControlView) findViewById(R.id.volume);
        ratingbar = (RatingBar) findViewById(R.id.ratingBar);

        // VolumeControlView에 터치 리스너 등록 (this가 onTouch 메서드를 처리함)
        vcv.setOnTouchListener(this);
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        float x = event.getX();
        float y = event.getY();

        // 뷰 내부의 getAngle을 호출하여 현재 터치 각도를 계산
        double angle = vcv.getAngle(x, y);
        float rating = ratingbar.getRating();

        // 각도에 따라 RatingBar 값 조절 (오른쪽 회전 시 증가, 왼쪽 회전 시 감소)
        if (angle > 0 && rating < 7.0) {
            // 오른쪽으로 회전
            ratingbar.setRating(rating + 1.0f);
        } else if (rating > 0.0) {
            // 왼쪽으로 회전
            ratingbar.setRating(rating - 1.0f);
        }

        return true;
    }
}