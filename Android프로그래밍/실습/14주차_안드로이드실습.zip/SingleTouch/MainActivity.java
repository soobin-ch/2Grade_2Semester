package com.example.singletouch;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // SingleTouchView를 생성하여 액티비티의 화면으로 설정합니다.
        // 두 번째 인자로 null을 전달하는 것은 XML 속성(AttributeSet) 없이 코드로만 생성하기 때문입니다.
        setContentView(new SingleTouchView(this, null));
    }
}