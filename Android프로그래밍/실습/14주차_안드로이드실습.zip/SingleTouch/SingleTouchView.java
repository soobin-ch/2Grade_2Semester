package com.example.singletouch;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class SingleTouchView extends View {
    private Paint paint = new Paint();
    private Path path = new Path();

    // 생성자: 뷰가 생성될 때 초기화 작업을 수행합니다.
    public SingleTouchView(Context context, AttributeSet attrs) {
        super(context, attrs);

        // 페인트(붓) 설정
        paint.setAntiAlias(true);        // 선분을 매끄럽게 그리기 위해 앤티 에일리어싱 설정
        paint.setStrokeWidth(10f);       // 선분의 두께를 10으로 설정
        paint.setColor(Color.BLUE);      // 색상을 파란색으로 설정
        paint.setStyle(Paint.Style.STROKE); // 채우지 않고 외곽선만 그리기
        paint.setStrokeJoin(Paint.Join.ROUND); // 선의 모서리를 둥글게 처리
    }

    @Override
    protected void onDraw(Canvas canvas) {
        // 현재까지 저장된 경로(path)를 페인트 설정을 이용해 그립니다.
        canvas.drawPath(path, paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float eventX = event.getX(); // 화면이 터치된 X 좌표
        float eventY = event.getY(); // 화면이 터치된 Y 좌표

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                // 터치가 시작되면 경로(Path)의 시작점을 해당 위치로 이동합니다.
                path.moveTo(eventX, eventY);
                return true; // 이벤트를 처리했음을 알림

            case MotionEvent.ACTION_MOVE:
                // 손가락이 움직이면 현재 위치까지 직선을 경로에 추가합니다.
                path.lineTo(eventX, eventY);
                break;

            case MotionEvent.ACTION_UP:
                // 손가락을 뗐을 때의 처리 (현재는 별도 동작 없음)
                break;

            default:
                return false;
        }

        // 화면을 갱신하여 onDraw()가 다시 호출되게 합니다.
        invalidate();
        return true;
    }
}