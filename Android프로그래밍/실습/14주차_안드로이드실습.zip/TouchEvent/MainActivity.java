package com.example.touchevent;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 앞서 정의한 CustomView 클래스의 인스턴스를 생성합니다.
        // 'this'는 현재 액티비티의 컨텍스트(Context)를 전달하는 것입니다.
        CustomView w = new CustomView(this);

        // 생성한 CustomView(w)를 액티비티의 화면 콘텐츠로 설정합니다.
        // 이제 앱을 실행하면 하얀 빈 화면 대신 터치 가능한 CustomView가 표시됩니다.
        setContentView(w);
    }
}