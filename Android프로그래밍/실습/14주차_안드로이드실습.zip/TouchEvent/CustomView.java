package com.example.touchevent;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CustomView extends View {

    // 원들의 정보를 저장할 리스트
    private List<Circle> circles = new ArrayList<>();
    private Paint paint;

    // 생성자
    public CustomView(Context context) {
        super(context);
        paint = new Paint();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // ArrayList에 저장된 원들을 꺼내서 다시 그린다.
        for (Circle circle : circles) {
            paint.setColor(circle.color);
            canvas.drawCircle(circle.x, circle.y, circle.radius, paint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // 뷰의 터치 이벤트를 재정의한다.
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            Random random = new Random();

            // 원의 반지름과 색상은 난수로 결정된다.
            float radius = random.nextInt(300);
            int color = Color.rgb(
                    random.nextInt(256),
                    random.nextInt(256),
                    random.nextInt(256)
            );

            float x = event.getX();
            float y = event.getY();

            circles.add(new Circle(x, y, radius, color));
            invalidate(); // 화면 다시 그리도록 요청 (onDraw 호출)
            return true;
        }
        return super.onTouchEvent(event);
    }

    // 원의 정보를 담기 위한 내부 클래스 정의
    private class Circle {
        float x, y, radius;
        int color;

        Circle(float x, float y, float radius, int color) {
            this.x = x;
            this.y = y;
            this.radius = radius;
            this.color = color;
        }
    }
}