package com.example.mydraw;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class SingleTouchView extends View {
    private Paint paint = new Paint();
    private Path path = new Path();
    private int paintColor = 0xFF000000; // 기본 검정색
    private Paint canvasPaint;
    private Canvas drawCanvas;
    private Bitmap canvasBitmap;

    public SingleTouchView(Context context, AttributeSet attrs) {
        super(context, attrs);
        paint.setAntiAlias(true);
        paint.setStrokeWidth(10f);
        paint.setColor(paintColor);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeJoin(Paint.Join.ROUND);
    }

    // 뷰의 크기가 변경될 때(최초 생성 시 등) 호출되어 비트맵을 생성합니다.
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        // 화면 크기에 맞는 비트맵 생성 (이곳에 그림이 영구적으로 저장됩니다)
        canvasBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); //
        drawCanvas = new Canvas(canvasBitmap);
        canvasPaint = new Paint(Paint.DITHER_FLAG);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        // 1. 저장된 비트맵(이전 그림들)을 먼저 그립니다.
        canvas.drawBitmap(canvasBitmap, 0, 0, canvasPaint); //
        // 2. 현재 그리고 있는 경로(실시간 선)를 그 위에 그립니다.
        canvas.drawPath(path, paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float touchX = event.getX();
        float touchY = event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                path.moveTo(touchX, touchY);
                break;
            case MotionEvent.ACTION_MOVE:
                path.lineTo(touchX, touchY);
                break;
            case MotionEvent.ACTION_UP:
                // 손을 떼면 현재 경로를 비트맵 캔버스에 영구적으로 그립니다.
                drawCanvas.drawPath(path, paint); //
                path.reset(); // 경로는 초기화합니다.
                break;
            default:
                return false;
        }
        invalidate(); // 화면 갱신
        return true;
    }

    // 외부(MainActivity)에서 색상을 변경할 때 호출하는 메서드
    public void setColor(String newColor) {
        invalidate();
        paintColor = Color.parseColor(newColor);
        paint.setColor(paintColor);
    }
}