package com.example.mydraw;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private SingleTouchView drawView;
    private ImageButton currPaint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drawView = (SingleTouchView) findViewById(R.id.drawing);

        // 팔레트 레이아웃에서 첫 번째 색상 버튼을 기본 선택 상태로 설정
        LinearLayout paintLayout = (LinearLayout) findViewById(R.id.paint_colors);
        currPaint = (ImageButton) paintLayout.getChildAt(0);
        // currPaint.setImageDrawable(...); // 선택된 버튼 스타일 변경 로직이 있다면 추가
    }

    // XML에서 android:onClick="clicked"로 연결된 메서드
    public void clicked(View view) {
        if (view != currPaint) {
            // 클릭된 버튼의 태그(색상 코드)를 가져와서 뷰에 적용
            String color = view.getTag().toString(); //
            drawView.setColor(color);
            currPaint = (ImageButton) view;
        }
    }
}