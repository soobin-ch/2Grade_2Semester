package com.example.imagescale;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // MyImageView를 생성하여 액티비티의 전체 화면으로 설정합니다.
        setContentView(new MyImageView(this)); //
    }
}