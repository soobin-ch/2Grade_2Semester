package com.example.imagescale;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

public class MyImageView extends View {
    private Drawable image;
    private ScaleGestureDetector gestureDetector;
    private float scale = 1.0f;

    public MyImageView(Context context) {
        super(context);
        // 리소스에서 이미지(lion)를 가져옵니다. (res/drawable/lion.png 또는 jpg 필요)
        image = context.getResources().getDrawable(R.drawable.lion); //
        setFocusable(true);

        // 이미지의 초기 크기 및 위치 설정 (0, 0 위치에 이미지 고유 크기만큼)
        image.setBounds(0, 0, image.getIntrinsicWidth(), image.getIntrinsicHeight()); //

        // 제스처 인식기 객체를 생성합니다.
        gestureDetector = new ScaleGestureDetector(context, new ScaleListener()); //
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // 캔버스의 현재 상태(변형 전)를 저장합니다.
        canvas.save(); //

        // 캔버스에 확대/축소 연산을 적용합니다. (scale 값이 1.0보다 크면 확대, 작으면 축소)
        canvas.scale(scale, scale); //

        // 이미지를 그립니다.
        image.draw(canvas); //

        // 캔버스의 상태를 복원합니다. (다음 프레임에 영향을 주지 않기 위함)
        canvas.restore(); //
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // 터치 이벤트를 제스처 인식기로 보내서 처리하게 합니다.
        gestureDetector.onTouchEvent(event); //
        invalidate(); // 화면 갱신 요청
        return true;
    }

    // 확대/축소 제스처를 감지하는 내부 리스너 클래스
    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            // 현재 스케일 값에 변화된 비율(ScaleFactor)을 곱해줍니다.
            scale *= detector.getScaleFactor(); //

            // 너무 작아지거나 너무 커지지 않도록 최대/최소 크기를 제한합니다.
            if (scale < 0.1f) // 최소 0.1배
                scale = 0.1f;
            if (scale > 10.0f) // 최대 10.0배
                scale = 10.0f; //

            invalidate(); // 화면 다시 그리기 요청
            return true;
        }
    }
}