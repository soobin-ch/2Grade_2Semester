package com.example.snowfall;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import java.util.Random;

public class Snowflake {
    // x, y: 현재 위치
    private float x, y;
    // radius: 눈송이의 크기 (반지름)
    private float radius;
    // speed: 눈이 떨어지는 속도
    private float speed;

    // 캔버스 크기 (초기값이며, onSizeChanged에서 갱신됨)
    private static int WIDTH = 1080;
    private static int HEIGHT = 1920;

    private final Paint paint;
    private final Random random = new Random();

    // 생성자: 초기 위치, 크기, 속도를 랜덤하게 설정
    public Snowflake(float minRadius, float maxRadius, float minSpeed, float maxSpeed) {
        // 눈의 크기는 minRadius와 maxRadius 사이에서 랜덤하게 결정
        this.radius = minRadius + random.nextFloat() * (maxRadius - minRadius);
        // 눈의 속도는 minSpeed와 maxSpeed 사이에서 랜덤하게 결정
        this.speed = minSpeed + random.nextFloat() * (maxSpeed - minSpeed);

        // 초기 위치는 화면 가로 영역 내에서 랜덤하게 설정
        this.x = random.nextFloat() * WIDTH;
        // 초기 y 위치는 화면 상단 바로 위에서 시작 (화면 밖)
        this.y = random.nextFloat() * HEIGHT;

        paint = new Paint();
        paint.setColor(Color.WHITE);
        paint.setAntiAlias(true);
    }

    // 화면 크기를 설정합니다.
    public static void setBounds(int width, int height) {
        WIDTH = width;
        HEIGHT = height;
    }

    // 눈송이의 위치를 갱신합니다.
    public void update() {
        // y 좌표를 속도만큼 증가시켜 눈이 아래로 떨어지게 합니다.
        y += speed;

        // 눈이 화면 아래로 완전히 떨어지면 다시 위에서 시작하도록 리셋합니다.
        if (y > HEIGHT + radius) {
            reset();
        }
    }

    // 눈송이 위치를 화면 상단 랜덤 위치로 리셋합니다.
    private void reset() {
        x = random.nextFloat() * WIDTH;
        y = -radius; // 화면 밖 위에서 시작
    }

    // 눈송이를 캔버스에 그립니다.
    public void draw(Canvas canvas) {
        canvas.drawCircle(x, y, radius, paint);
    }
}