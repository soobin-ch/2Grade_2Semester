package com.example.snowfall;

import android.graphics.Canvas;
import android.view.SurfaceHolder;

public class SnowingThread extends Thread {

    private boolean isRunning = false;
    private final SurfaceHolder surfaceHolder;
    private final SnowingView snowingView;
    private static final int FRAME_DELAY = 10; // 10ms 지연 (약 100 FPS)

    public SnowingThread(SurfaceHolder holder, SnowingView view) {
        this.surfaceHolder = holder;
        this.snowingView = view;
    }

    public void setRunning(boolean running) {
        this.isRunning = running;
    }

    @Override
    public void run() {
        long startTime;
        long timeMillis;
        long waitTime;

        // 메인 루프
        while (isRunning) {
            startTime = System.nanoTime();
            Canvas canvas = null;

            try {
                canvas = surfaceHolder.lockCanvas(null); // 캔버스를 잠근다.
                synchronized (surfaceHolder) {
                    if (canvas != null) {
                        snowingView.updateSnowflakes(); // 눈 위치 갱신
                        snowingView.drawSnow(canvas);    // 눈 그리기
                    }
                }
            } finally {
                // 캔버스를 해제하고 화면에 표시한다.
                if (canvas != null) {
                    surfaceHolder.unlockCanvasAndPost(canvas);
                }
            }

            // FPS 제어를 위한 딜레이 계산
            timeMillis = (System.nanoTime() - startTime) / 1000000;
            waitTime = FRAME_DELAY - timeMillis;

            if (waitTime > 0) {
                try {
                    sleep(waitTime);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }
}