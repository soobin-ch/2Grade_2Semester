package com.example.snowfall;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class SnowingView extends SurfaceView implements SurfaceHolder.Callback {

    private SnowingThread thread;
    private Snowflake[] snowflakes;

    // 사용자 설정 가능 속성
    private int snowflakeCount = 30; // 기본 눈송이 개수
    private float minRadius = 30f;    // 눈 최소 크기
    private float maxRadius = 35f;   // 눈 최대 크기
    private float minSpeed = 5f;     // 눈 최소 속도
    private float maxSpeed =15f;     // 눈 최대 속도

    // 생성자
    public SnowingView(Context context) {
        this(context, null);
    }
    public SnowingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        getHolder().addCallback(this); // 콜백 등록
        setFocusable(true);
        // SurfaceView의 배경이 투명하게 설정되도록 설정합니다.
        setZOrderOnTop(true);
        getHolder().setFormat(android.graphics.PixelFormat.TRANSPARENT);
    }

    // MainActivity에서 설정값을 받아 초기화하는 메서드
    public void initialize(int count, float minR, float maxR, float minS, float maxS) {
        this.snowflakeCount = count;
        this.minRadius = minR;
        this.maxRadius = maxR;
        this.minSpeed = minS;
        this.maxSpeed = maxS;

        // 기존 스레드가 있으면 중지 후 재생성
        if (thread != null) {
            thread.setRunning(false);
            try { thread.join(); } catch (InterruptedException e) {}
        }

        // 눈송이 배열 초기화 및 생성
        snowflakes = new Snowflake[snowflakeCount];
        for (int i = 0; i < snowflakeCount; i++) {
            snowflakes[i] = new Snowflake(minRadius, maxRadius, minSpeed, maxSpeed);
        }

        // 스레드 재생성
        thread = new SnowingThread(getHolder(), this);
    }

    // 눈송이들의 위치를 갱신합니다. (스레드에서 호출됨)
    public void updateSnowflakes() {
        if (snowflakes != null) {
            for (Snowflake flake : snowflakes) {
                flake.update();
            }
        }
    }

    // 눈송이들을 캔버스에 그립니다. (스레드에서 호출됨)
    public void drawSnow(Canvas canvas) {

        // 🌟 수정된 부분: 이전 프레임을 투명하게 지웁니다.
        // PorterDuff.Mode.CLEAR를 사용하여 캔버스 픽셀들을 투명(Alpha=0)으로 만듭니다.
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);

        if (snowflakes != null) {
            for (Snowflake flake : snowflakes) {
                flake.draw(canvas);
            }
        }
    }

    // SurfaceHolder.Callback 구현

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        // 화면 크기가 확정되면 Snowflake 클래스에 경계를 알려줍니다.
        Snowflake.setBounds(getWidth(), getHeight());

        // 초기화 메서드가 호출되지 않았다면 기본값으로 초기화
        if (snowflakes == null) {
            initialize(snowflakeCount, minRadius, maxRadius, minSpeed, maxSpeed);
        }

        // 스레드 시작
        thread.setRunning(true);
        thread.start();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        // 스레드를 안전하게 중지
        boolean retry = true;
        thread.setRunning(false);
        while (retry) {
            try {
                thread.join();
                retry = false;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        // 화면 크기가 변경될 때 Snowflake 클래스에 경계 갱신
        Snowflake.setBounds(width, height);
    }
}