package com.example.snowfall;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. XML 레이아웃을 로드합니다.
        setContentView(R.layout.activity_main);

        // 2. XML에서 SnowingView를 ID로 찾습니다.
        SnowingView snowingView = findViewById(R.id.snowing_view);

        // 3. 원하는 눈 내리는 설정을 지정합니다.
        int snowflakeCount = 150; // 눈송이 개수 (조절 가능)
        float minRadius = 3f;     // 눈 최소 크기 (조절 가능)
        float maxRadius = 10f;    // 눈 최대 크기 (조절 가능)
        float minSpeed = 3f;      // 눈 최소 속도 (조절 가능)
        float maxSpeed = 15f;     // 눈 최대 속도 (조절 가능)

        // 4. SnowingView를 설정값으로 초기화합니다.
        // XML을 사용하더라도 초기화 메서드는 직접 호출해야 합니다.
        if (snowingView != null) {
            snowingView.initialize(snowflakeCount, minRadius, maxRadius, minSpeed, maxSpeed);
        }
    }
}