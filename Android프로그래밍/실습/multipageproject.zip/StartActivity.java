package com.example.multipage;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class StartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 이 Activity가 사용할 레이아웃 파일을 지정합니다.
        setContentView(R.layout.activity_start);
    }
}
