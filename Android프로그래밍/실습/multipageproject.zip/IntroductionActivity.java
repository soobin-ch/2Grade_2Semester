package com.example.multipage;

// IntroductionActivity.java 파일


import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class IntroductionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 이 Activity가 사용할 레이아웃 파일을 지정합니다.
        setContentView(R.layout.activity_introduction);
    }
}
