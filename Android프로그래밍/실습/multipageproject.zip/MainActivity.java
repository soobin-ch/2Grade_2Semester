package com.example.multipage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button button1;
    private Button button2;
    private Button button3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // activity_main.xml 레이아웃 파일 설정
        setContentView(R.layout.activity_main);

        // 1. 레이아웃에서 버튼 위젯들을 ID로 찾기
        button1 = findViewById(R.id.button_1);
        button2 = findViewById(R.id.button_2);
        button3 = findViewById(R.id.button_3);

        // 2. 각 버튼에 클릭 리스너 설정
        setupButtonListeners();
    }

    private void setupButtonListeners() {
        // INTRODUTION 버튼 (button_1) 클릭 리스너
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // IntroductionActivity.java로 이동
                navigateToActivity(IntroductionActivity.class);
            }
        });

        // SETTING 버튼 (button_2) 클릭 리스너
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // SettingActivity.java로 이동
                navigateToActivity(SettingActivity.class);
            }
        });

        // START 버튼 (button_3) 클릭 리스너
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // StartActivity.java로 이동
                navigateToActivity(StartActivity.class);
            }
        });
    }

    /**
     * 지정된 Activity로 이동하는 범용 함수
     * @param targetActivity 이동할 Activity 클래스
     */
    private void navigateToActivity(Class<?> targetActivity) {
        // Intent 객체 생성 (현재 Activity에서 목표 Activity로)
        Intent intent = new Intent(MainActivity.this, targetActivity);
        // Activity 시작
        startActivity(intent);
    }
}