package com.example.alertdialogtestradio;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

// MainActivity.java

public class MainActivity extends AppCompatActivity {

    private String selectedDrink = "커피"; // 기본 선택값
    ImageView imageview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageview = findViewById(R.id.imageView);
        Button showDialogButton = findViewById(R.id.show_dialog_button);

        // 버튼이 눌리면 라디오 버튼이 있는 대화 상자를 생성한다.
        showDialogButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDrinkSelectionDialog();
            }
        });
    }

    private void showDrinkSelectionDialog() {
        // 빌더 객체를 먼저 생성하여 여러 속성을 설정한다.
        final String[] drinks = {"커피", "티", "밀크"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("음료 선택")
                .setSingleChoiceItems(drinks, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        selectedDrink = drinks[which];

                        // which는 선택된 항목의 인덱스입니다.
                        if (which == 0)
                            imageview.setImageResource(R.drawable.coffee);
                        else if (which == 1)
                            // **오류로 추정되는 부분**: 이미지에선 which==1일 때도 tea였으나,
                            // drinks[1]은 "티"이므로 R.drawable.tea가 적절합니다.
                            imageview.setImageResource(R.drawable.tea);
                        else // which == 2 (밀크)
                            imageview.setImageResource(R.drawable.milk);
                    }
                })
                // '확인' 버튼 설정 (선택 항목에 대한 추가 작업 수행)
                .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // 선택한 음료에 대한 추가 작업 수행
                        // 실제 액션을 수행하거나 화면에 표시하는 방식으로 변경 가능
                        dialog.dismiss();
                    }
                })
                // '취소' 버튼 설정
                .setNegativeButton("취소", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        // 다이얼로그 생성 및 표시
        builder.create().show();
    }
}