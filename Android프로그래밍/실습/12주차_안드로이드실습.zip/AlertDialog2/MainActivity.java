package com.example.alertdialog2;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int DIALOG_YES_NO_MESSAGE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button b = (Button) findViewById(R.id.Button01);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // showDialog는 onCreateDialog를 호출함 (API 레벨 26에서 Deprecated 됨)
                showDialog(DIALOG_YES_NO_MESSAGE);
            }
        });
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DIALOG_YES_NO_MESSAGE:
                AlertDialog.Builder builder
                        = new AlertDialog.Builder(this); // context: this는 IDE가 붙인 힌트임

                builder.setTitle("종료 확인 대화 상자")
                        .setMessage("애플리케이션을 종료하시겠습니까?")
                        .setCancelable(false) // 백 버튼으로 닫기 불가
                        .setPositiveButton("Yes", // 'Yes' 버튼
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,
                                            int whichButton) {
                            finish(); // 앱 종료
                        }
                    })
                       .setNegativeButton("No", // 'No' 버튼
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,
                                            int whichButton) {
                            dialog.cancel(); // 다이얼로그 닫기
                        }
                    });

                AlertDialog alert = builder.create();
                return alert;

            default:
                return null;
        }
    }
}