package com.example.customdialog;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView text;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text = (TextView) findViewById(R.id.textView);
    }

    // activity_main.xml의 버튼(id: button)에 연결된 클릭 리스너
    public void onClick(View v) {
        final Dialog loginDialog = new Dialog(this);
        loginDialog.setContentView(R.layout.custom_dialog);
        loginDialog.setTitle("로그인 화면");

        // 다이얼로그 뷰 내부의 요소들 참조 가져오기
        Button login = (Button) loginDialog.findViewById(R.id.login);
        Button cancel = (Button) loginDialog.findViewById(R.id.cancel);
        final EditText username = (EditText) loginDialog.findViewById(R.id.username);
        final EditText password = (EditText) loginDialog.findViewById(R.id.password);

        // '로그인' 버튼 리스너
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 사용자 이름과 비밀번호가 모두 1글자 이상인지 확인 (입력값 검증)
                if (username.getText().toString().trim().length() > 0
                        && password.getText().toString().trim().length() > 0) {

                    Toast.makeText(getApplicationContext(), "로그인 성공",
                            Toast.LENGTH_LONG).show();

                    // 메인 화면 TextView에 로그인 정보 출력
                    text.setText("아이디: " + username.getText()
                            + "\n패스워드: " + password.getText());

                    loginDialog.dismiss(); // 다이얼로그 닫기
                } else {
                    Toast.makeText(getApplicationContext(), "다시 입력하시오",
                            Toast.LENGTH_LONG).show();
                }
            }
        });

        // '취소' 버튼 리스너
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginDialog.dismiss(); // 다이얼로그 닫기
            }
        });

        loginDialog.show(); // 다이얼로그 표시
    }
}