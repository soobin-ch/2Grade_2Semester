package com.example.eggtimer;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

// MainActivity.java

public class MainActivity extends AppCompatActivity {

    private EditText mEditText;
    String NOTIFICATION_CHANNEL_ID = "my_channel_id_01";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mEditText = (EditText) findViewById(R.id.edit);
        createNotificationChannel();
    }

    // 알림 채널을 생성한다. (Android 8.0/Oreo 이상 필요)
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel notificationChannel = new NotificationChannel(
                    NOTIFICATION_CHANNEL_ID,
                    "My Notifications",
                    NotificationManager.IMPORTANCE_DEFAULT);
            notificationChannel.setDescription("Channel description");

            NotificationManager notificationManager = (NotificationManager)
                    getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }

    public void startTimer(View view) {
        String s = mEditText.getText().toString();
        // EditText의 입력 (예: "01:00")에서 분과 초를 파싱
        int min = Integer.parseInt(s.substring(0, 2));
        int sec = Integer.parseInt(s.substring(3, 5));

        // 타이머 생성 및 시작
        new CountDownTimer(min * 60 * 500 + sec * 1000, 1000) {

            public void onTick(long millisUntilFinished) {
                // 남은 시간을 초 단위로 변환하여 EditText에 표시
                mEditText.setText("" + (int) (millisUntilFinished / 1000) + "초");
            }

            public void onFinish() {
                // 타이머가 끝나면 알림을 보낸다.
                mEditText.setText("done!");
                sendNotification();
            }
        }.start();
    }

    public void sendNotification() {
        // 디자인 패턴 중에서 빌더 패턴을 사용하고 있다.
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this,
                NOTIFICATION_CHANNEL_ID);

        // 알림이 클릭되면 이 이벤트가 보내진다.
        Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("http://www.google.com/"));

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
                intent, PendingIntent.FLAG_IMMUTABLE); // FLAG_IMMUTABLE 사용

        notificationBuilder.setSmallIcon(R.drawable.ic_launcher_background)
                .setContentTitle("Egg Timer")
                .setContentText("계란 삶기가 완료되었습니다.")
                .setContentIntent(pendingIntent); // 알림 클릭 시 실행될 인텐트 설정

        NotificationManager notificationManager = (NotificationManager)
                getSystemService(Context.NOTIFICATION_SERVICE);

        // 알림 표시 (*notification id*/1)
        notificationManager.notify(1, notificationBuilder.build());
    }
}