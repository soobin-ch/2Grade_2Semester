package com.example.alertdialogtest;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void open(View view) {
        // 빌더 객체를 생성한다.
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

        alertDialogBuilder.setTitle("AlertDiloag Test");
        // 대화상자의 메시지 부분 설정
        alertDialogBuilder.setMessage("결제하시겠습니까?");

        // 대화상자의 "yes" 버튼 부분 설정
        alertDialogBuilder.setPositiveButton("yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        Toast.makeText(MainActivity.this, "결제가 완료되었습니다.",
                                Toast.LENGTH_LONG).show();
                        // finish(); // 이미지가 잘려서 이 위치에 있었는지 확실하지 않지만, 보통 finish()는 취소 버튼에서 사용됨.
                    }
                });

        // Negative Button (취소 버튼)이 설정되어 있었을 수 있으며,
        // 아래 코드는 Positive Button 이후의 나머지 코드입니다.

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
}