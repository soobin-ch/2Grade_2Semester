package com.example.listview02;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 데이터 배열 생성
        // resources.xml에 정의된 string-array name="fruits" 리소스를 가져옴
        String[] data
                = getResources().getStringArray(R.array.fruits);

        // ArrayAdapter를 사용하여 데이터를 ListView에 연결
        // R.layout.list_item: 커스텀 항목 레이아웃
        // R.id.label: 커스텀 레이아웃 내의 텍스트 뷰 ID (데이터가 바인딩될 위치)
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                R.layout.list_item, R.id.label, data);

        ListView listView = findViewById(R.id.listView);

        // 리스트 뷰에 어댑터 설정
        listView.setAdapter(adapter);

        // ListView에 항목 클릭 리스너 추가
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                // 클릭한 항목의 텍스트를 가져와서 토스트 메시지로 표시
                String selectedItem = data[position];
                Toast.makeText(getApplicationContext(),
                        "선택한 항목: " + selectedItem,
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}