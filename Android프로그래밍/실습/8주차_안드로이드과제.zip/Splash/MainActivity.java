package com.example.splash;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int SPLASH_TIMEOUT = 2000; // 스플래시 화면을 보여줄 시간 (2초)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 일정 시간 후에 로그인 화면으로 이동
        new Handler().postDelayed(new Runnable() {  // ①
            @Override
            public void run() {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class); // ②
                startActivity(intent);  // ③
                finish(); // 스플래시 화면을 종료 ④
            }
        }, SPLASH_TIMEOUT);
    }
}