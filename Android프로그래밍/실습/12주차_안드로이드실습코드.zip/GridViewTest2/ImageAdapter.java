package com.example.gridviewtest;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

public class ImageAdapter extends BaseAdapter {

    private Context mContext;

    // 그리드 뷰에 표시할 이미지 리소스 ID 배열
    private Integer[] mThumbIds = {
            R.drawable.sample_1, R.drawable.sample_2,
            R.drawable.sample_3, R.drawable.sample_4,
            R.drawable.sample_1, R.drawable.sample_2,
            R.drawable.sample_3, R.drawable.sample_4,
            R.drawable.sample_1, R.drawable.sample_2,
            R.drawable.sample_3, R.drawable.sample_4,
            R.drawable.sample_1, R.drawable.sample_2,
            R.drawable.sample_3, R.drawable.sample_4,
            R.drawable.sample_1, R.drawable.sample_2,
            R.drawable.sample_3, R.drawable.sample_4,
    };

    // 생성자: Context를 받아 저장합니다.
    public ImageAdapter (Context c) {
        mContext = c;
    }

    // 항목의 총 개수 반환
    @Override
    public int getCount() {
        return mThumbIds.length;
    }

    // 지정된 위치의 항목 반환
    @Override
    public Object getItem(int position) {
        return mThumbIds[position];
    }

    // 지정된 위치의 항목 ID 반환
    @Override
    public long getItemId(int position) {
        return position;
    }

    // 항목 뷰를 생성하거나 재사용하여 반환
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;

        // 뷰 재사용 로직 (convertView가 null이면 새로 생성)
        if (convertView == null) {
            imageView = new ImageView(mContext);
            // 레이아웃 매개변수 설정 (250x250 픽셀 크기)
            imageView.setLayoutParams(new GridView.LayoutParams(250, 250));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(8, 8, 8, 8);
        } else {
            // convertView를 재활용하여 메모리 효율성 증대
            imageView = (ImageView) convertView;
        }

        // 이미지 리소스 설정
        imageView.setImageResource(mThumbIds[position]);

        return imageView;
    }
}