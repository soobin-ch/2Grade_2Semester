package com.example.gridviewtest;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // R.layout.activity_main 레이아웃을 설정 (이 레이아웃에 GridView가 정의되어 있어야 함)
        setContentView(R.layout.activity_main);

        // GridView 컴포넌트 찾기 (ID: GridView01)
        GridView gridView = (GridView) findViewById(R.id.GridView01);

        // ImageAdapter를 생성하여 GridView에 설정
        // 'this'는 Context를 ImageAdapter 생성자에 전달합니다.
        gridView.setAdapter(new ImageAdapter(this));

        // 아이템 클릭 리스너 설정
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                // 클릭된 이미지의 위치(position)를 Toast 메시지로 표시
                Toast.makeText(MainActivity.this,
                        "text: " + position,
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}