package com.example.viewpager;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import java.util.Objects;

public class MyPagerAdapter extends PagerAdapter {

    Context context;
    int[] images;
    LayoutInflater layoutInflater;

    // 생성자
    public MyPagerAdapter(Context context, int[] images) {
        this.context = context;
        this.images = images;
        // LayoutInflater 초기화는 생성자 이후에 이루어져야 합니다.
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    // 항목의 개수 반환
    @Override
    public int getCount() {
        return images.length;
    }

    // 뷰와 객체가 연결되었는지 확인
    // ViewPager에서 View와 Object(여기서는 View 자체)가 동일한지 확인합니다.
    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        // LinearLayour 형 변환은 item.xml의 최상위 태그에 따라 달라질 수 있습니다.
        return view == ((LinearLayout) object);
    }

    // 항목 생성 및 초기화
    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, final int position) {
        // item.xml 레이아웃 인플레이트
        View itemView = layoutInflater.inflate(R.layout.item, container, false);

        // ImageView 찾기 및 리소스 설정
        ImageView imageView = (ImageView) itemView.findViewById(R.id.imageView);
        imageView.setImageResource(images[position]);

        // 컨테이너(ViewPager)에 뷰 추가
        Objects.requireNonNull(container).addView(itemView);

        return itemView;
    }

    // 항목 제거
    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        // 컨테이너(ViewPager)에서 뷰 제거
        container.removeView((LinearLayout) object);
    }
}