package com.example.viewpager;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

public class MainActivity extends AppCompatActivity {

    ViewPager viewPager;
    // 이미지 리소스 배열 (R.drawable.image1, image2, image3가 존재한다고 가정)
    int[] images = {R.drawable.image1, R.drawable.image2, R.drawable.image3};
    MyPagerAdapter myPagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. ViewPager 컴포넌트 찾기
        viewPager = (ViewPager)findViewById(R.id.viewPager);

        // 2. 어댑터 생성 및 초기화
        myPagerAdapter = new MyPagerAdapter(MainActivity.this, images);

        // 3. ViewPager에 어댑터 연결
        viewPager.setAdapter(myPagerAdapter);
    }
}