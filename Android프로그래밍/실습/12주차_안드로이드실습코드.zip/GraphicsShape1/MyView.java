package com.example.graphicsshape1;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

public class MyView extends View {
    public MyView(Context context) {
        super(context);
        setBackgroundColor(Color.BLUE); // 뷰의 배경색을 파란색으로 설정
    }

    @SuppressLint("DrawAllocation")
    @Override
    protected void onDraw(Canvas canvas) {
        // 붓(Paint) 객체 초기화 및 기본 색상 설정 (노란색)
        @SuppressLint("DrawAllocation") Paint paint = new Paint();
        paint.setColor(Color.YELLOW);

        // 1. 캔버스 배경을 파란색으로 채움
        canvas.drawColor(Color.BLUE);

        // 2. 둥근 사각형 그리기 (노란색)
        // RectF(left, top, right, bottom) 영역에 둥근 모서리(rx=15, ry=15)를 적용하여 그림
        canvas.drawRoundRect(new RectF(30, 50, 330, 550), 15, 15, paint);

        // 3. 타원형/원 그리기 (노란색)
        // RectF(left, top, right, bottom) 영역에 꽉 차게 타원형을 그림.
        // 좌우 길이가 같으므로 원형으로 그려짐 (화면 상단 우측의 노란색 원)
        canvas.drawOval(new RectF(450, 50, 750, 550), paint);

        // 4. 붓 색상을 빨간색으로 변경
        paint.setColor(Color.RED);

        // 5. 호(Arc) 그리기 (빨간색)
        // RectF(30, 600, 330, 1100) 영역에 호를 그림.
        // 360도에서 시작하여 1000도 만큼 호를 그리라는 것은 캔버스의 좌표계와
        // 각도 시스템에 따라 복잡하지만, 이 코드는 결과적으로 원처럼 보입니다.
        // 'true'는 호의 중심을 채워 원처럼 보이게 합니다. (화면 중앙의 빨간색 원)
        canvas.drawArc(new RectF(30, 600, 330, 1100), 360, 1000, true, paint);

        // 6. 붓 색상을 다시 노란색으로 변경
        paint.setColor(Color.YELLOW);

        // 7. 다중 선(Lines) 그리기 (노란색, 지그재그 모양)
        // float[] 배열 pts에 점들의 (x, y) 좌표 쌍을 순서대로 저장:
        // (x1, y1, x2, y2, x3, y3, ...)
        float[] pts = {30, 1250, 300, 1350, 300, 1350, 60, 1450, 60, 1450, 360, 1500};

        paint.setStrokeWidth(10); // 선 굵기를 10픽셀로 설정

        // pts 배열의 좌표들을 묶어 선을 그립니다. (화면 하단의 지그재그 선)
        canvas.drawLines(pts, paint);
    }
}