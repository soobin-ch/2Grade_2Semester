package com.example.graphic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class MyView extends View {
    public MyView(Context context) {
        super(context);
        setBackgroundColor(Color.BLUE); // 뷰의 배경색을 파란색으로 설정
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Paint paint = new Paint(); // 붓(Paint) 객체 생성
        paint.setColor(Color.YELLOW); // 붓의 색상을 노란색으로 설정
        paint.setStrokeWidth(20); // 선의 굵기를 20픽셀로 설정

        // 1. 선 그리기 (drawLine)
        // (시작x, 시작y, 끝x, 끝y, 붓)
        canvas.drawLine(100, 100, 700, 100, paint);

        // 2. 사각형 그리기 (drawRect)
        // (좌상단x, 좌상단y, 우하단x, 우하단y, 붓)
        canvas.drawRect(300, 300, 700, 700, paint);

        // 3. 원 그리기 (drawCircle)
        // (중심x, 중심y, 반지름, 붓)
        canvas.drawCircle(300, 1200, 200, paint);

        // 4. 텍스트 그리기 (drawText)
        paint.setTextSize(80); // 텍스트 크기를 80으로 설정
        // (텍스트 내용, 시작x, 시작y, 붓)
        canvas.drawText("This is a test.", 100, 900, paint);
    }
}