package com.example.customlistview;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // 1. ListView 변수 선언
    ListView list;

    // 2. 영화 제목 데이터 배열 정의
    String[] titles = {
            "The Wizard of Oz (1939)",
            "Citizen Kane (1941)",
            "All About Eve (1950)",
            "The Third Man (1949)",
            "A Hard Day's Night (1964)",
            "Modern Times (1936)",
            "Metropolis (1927)",
            "Raiders (1982)",
            "Back to the Future (1982)", // Note: 1985로 추정되나 이미지에 따라 1982로 작성
            "Mission Impossible (1996)"
    };

    // 3. 이미지 리소스 ID 배열 정의
    Integer[] images = {
            R.drawable.movie1,
            R.drawable.movie2,
            R.drawable.movie3,
            R.drawable.movie4,
            R.drawable.movie5,
            R.drawable.movie6,
            R.drawable.movie7,
            R.drawable.movie8,
            R.drawable.movie9,
            R.drawable.movie10
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // activity_main.xml 레이아웃 설정
        setContentView(R.layout.activity_main);

        // 4. CustomAdapter 생성 및 초기화
        // titles 및 images 배열은 CustomAdapter 클래스의 생성자에 따라 필요할 수 있습니다.
        // 여기서는 titles만 전달하며, CustomAdapter 내에서 나머지 데이터를 처리하도록 가정합니다.
        CustomAdapter adapter = new CustomAdapter(MainActivity.this, titles, images);

        // 5. ListView 컴포넌트 찾기
        list = (ListView)findViewById(R.id.list);

        // 6. ListView에 어댑터 연결
        list.setAdapter(adapter);

        // 7. 아이템 클릭 리스너 설정
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                // 클릭된 아이템의 제목을 Toast 메시지로 표시
                Toast.makeText(getBaseContext(), titles[position],
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}