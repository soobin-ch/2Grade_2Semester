package com.example.customlistview;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class CustomAdapter extends ArrayAdapter<String> {

    private final Activity context;
    // titles 배열은 super() 호출 시 사용되지만, getView()에서 명시적으로 접근하기 위해 필요합니다.
    private final String[] titles;
    // images 배열은 ImageView에 리소스를 설정하기 위해 필요합니다.
    // MainActivity에서 Integer[] images로 선언되어 있다고 가정합니다.
    private final Integer[] images;

    // CustomAdapter 생성자 (image_0e8737.png 기반)
    // titles와 images 배열을 추가로 받아야 getView()를 완성할 수 있습니다.
    public CustomAdapter(Activity context, String[] titles, Integer[] images) {
        super(context, R.layout.listitem, titles); // R.layout.listitem은 목록 항목 레이아웃입니다.
        this.context = context;
        this.titles = titles;
        this.images = images;
    }

    // getView() 메서드 재정의 (image_0e873a.jpg 기반)
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater inflater = context.getLayoutInflater();

        // convertView가 null이면 새로운 View를 인플레이트합니다.
        View rowView = inflater.inflate(R.layout.listitem, null, true);
        // Note: image_0e873a.jpg에는 attachToRoot: true로 되어 있지만, ListView의 어댑터에서는 보통 null 또는 false를 사용합니다.
        // 이미지에 명시된 대로 코드를 재구성하지만, 일반적으로는 'null, false' 또는 'parent, false'가 사용됩니다.
        // View rowView = inflater.inflate(R.layout.listitem, parent, false);

        // 뷰 컴포넌트 찾기
        ImageView imageView = (ImageView) rowView.findViewById(R.id.image);
        TextView titleText = (TextView) rowView.findViewById(R.id.title);
        TextView ratingText = (TextView) rowView.findViewById(R.id.rating);
        TextView genreText = (TextView) rowView.findViewById(R.id.genre);
        TextView yearText = (TextView) rowView.findViewById(R.id.releaseYear);

        // 데이터 바인딩 (image_0e873a.jpg 기반의 로직 사용)
        titleText.setText(titles[position]);
        imageView.setImageResource(images[position]);

        // rating, genre, year 필드는 position에 기반한 더미 데이터 또는 하드코딩된 값으로 설정됩니다.
        ratingText.setText("9.0" + position);
        genreText.setText("DRAMA");
        yearText.setText("1930" + position + "");

        return rowView;
    }
}