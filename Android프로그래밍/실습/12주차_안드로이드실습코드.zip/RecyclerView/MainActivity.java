package com.example.recyclerview;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity implements MyRecyclerViewAdapter.ItemClickListener {

    MyRecyclerViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. 더미 데이터 생성 (100개 항목)
        String[] data = new String[100];
        for (int i = 1; i <= 100; i++) {
            data[i - 1] = "friend #" + i;
        }

        // 2. RecyclerView 설정
        RecyclerView recyclerView = findViewById(R.id.rview);

        // 3. 레이아웃 매니저 설정 (3열 그리드)
        int columns = 3;
        recyclerView.setLayoutManager(new GridLayoutManager(this, columns));

        // 4. 어댑터 생성 및 연결
        adapter = new MyRecyclerViewAdapter(this, data);

        // 5. 클릭 리스너 설정 (MainActivity가 ItemClickListener 인터페이스를 구현)
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);
    }

    // 6. ItemClickListener 인터페이스 구현
    @Override
    public void onItemClick(View view, int position) {
        // Logcat 출력
        Log.i("TAG", "item: " + adapter.getItem(position) + " number: " + position);

        // Toast 메시지 표시
        Toast.makeText(this, "item: " + adapter.getItem(position)
                + " number: " + position, Toast.LENGTH_SHORT).show();
    }
}