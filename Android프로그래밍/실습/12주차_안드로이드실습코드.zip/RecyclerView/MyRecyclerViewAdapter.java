package com.example.recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.ViewHolder> {

    private String[] mData;
    private LayoutInflater mInflater;
    private ItemClickListener mClickListener;

    // 1. 생성자
    MyRecyclerViewAdapter(Context context, String[] data) {
        this.mInflater = LayoutInflater.from(context);
        this.mData = data;
    }

    // 2. 뷰 홀더 생성
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.item, parent, false);
        return new ViewHolder(view);
    }

    // 3. 뷰 홀더에 데이터 바인딩
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.myTextView.setText(mData[position]);
    }

    // 4. 전체 항목 개수 반환
    @Override
    public int getItemCount() {
        return mData.length;
    }

    // 5. 항목 데이터를 반환하는 헬퍼 메서드
    String getItem(int id) {
        return mData[id];
    }

    // 6. 클릭 리스너 설정
    void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }

    // 7. ViewHolder 클래스 (항목 뷰의 참조를 저장)
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView myTextView;

        ViewHolder(View itemView) {
            super(itemView);
            myTextView = itemView.findViewById(R.id.info_text);
            itemView.setOnClickListener(this); // 항목 전체에 클릭 리스너 설정
        }

        @Override
        public void onClick(View view) {
            if (mClickListener != null) {
                // 어댑터 포지션을 MainActivity로 전달
                mClickListener.onItemClick(view, getAdapterPosition());
            }
        }
    }

    // 8. 항목 클릭 리스너 인터페이스
    public interface ItemClickListener {
        void onItemClick(View view, int position);
    }
}
