package com.example.spinnertest;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Spinner 컴포넌트 찾기
        Spinner spinner = (Spinner) findViewById(R.id.spinner);

        // 2. 리소스에서 ArrayAdapter 생성
        // planets_array 리소스를 사용하여 어댑터 생성
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.planets_array,
                android.R.layout.simple_spinner_item
        );

        // 3. 드롭다운 뷰 리소스 지정 (사용자가 클릭했을 때 표시되는 항목의 모양)
        // simple_spinner_dropdown_item은 안드로이드가 제공하는 표준 드롭다운 뷰입니다.
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // 4. 어댑터를 Spinner에 연결하여 데이터 표시
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            // 1. 항목이 선택되었을 때 호출되는 메서드
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int pos, long id) {

                // Toast 메시지를 생성하여 선택된 항목의 텍스트를 표시
                Toast.makeText(parent.getContext(),
                        "선택된 행성은 " + parent.getItemAtPosition(pos).toString(),
                        Toast.LENGTH_SHORT).show();
            }

            // 2. 아무것도 선택되지 않았을 때 호출되는 메서드
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // 이 예시에서는 아무것도 하지 않음 (메서드만 구현)
            }
        });
    }
}