package com.example.datetimepicker;


import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private TextView selectedDateText, selectedTimeText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        selectedDateText = findViewById(R.id.selected_date_text);
        selectedTimeText = findViewById(R.id.selected_time_text);

        // --- 날짜 선택 버튼 리스너 설정 ---
        Button selectDateButton = findViewById(R.id.select_date_button);
        selectDateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });

        // --- 시간 선택 버튼 리스너 설정 ---
        Button selectTimeButton = findViewById(R.id.select_time_button);
        selectTimeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePickerDialog();
            }
        });
    }

    /**
     * 날짜 선택 다이얼로그를 표시하고 선택된 날짜를 처리합니다.
     */
    private void showDatePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

        // DatePickerDialog 대화상자 생성
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int selectedYear, int selectedMonth,
                                          int selectedDayOfMonth) {
                        // 월은 0부터 시작하므로 +1 해줍니다.
                        String selectedDate = selectedYear + "-" + (selectedMonth + 1) + "-" +
                                selectedDayOfMonth;
                        // 선택된 날짜를 TextView에 설정
                        selectedDateText.setText("선택한 날짜: " + selectedDate);
                    }
                },
                year, month, dayOfMonth // 기본 값으로 현재 날짜 설정
        );

        datePickerDialog.show();
    }

    /**
     * 시간 선택 다이얼로그를 표시하고 선택된 시간을 처리합니다.
     */
    private void showTimePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(
                this,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int selectedHour, int selectedMinute) {
                        // 선택된 시간을 TextView에 설정
                        String selectedTime = selectedHour + ":" + selectedMinute;
                        selectedTimeText.setText("선택한 시간: " + selectedTime);
                    }
                },
                hour, minute,
                true // 24시간 형식 (true) 또는 12시간 형식 (false) 설정
        );

        timePickerDialog.show();
    }
}