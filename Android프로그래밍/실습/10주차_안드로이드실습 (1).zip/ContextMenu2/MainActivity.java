package com.example.contextmenu2;

import android.os.Bundle;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity
        implements View.OnLongClickListener, ActionMode.Callback {

    ActionMode mActionMode; // 액션 모드 객체를 저장할 변수

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView text = (TextView) findViewById(R.id.TextView01);
        // TextView에 롱 클릭 리스너를 설정합니다.
        text.setOnLongClickListener(this);
    }

    // =========================================================
    // View.OnLongClickListener 구현
    // =========================================================

    @Override
    public boolean onLongClick(View view) {
        if (mActionMode != null) {
            return false; // 이미 액션 모드가 활성화되어 있다면 추가 처리를 막습니다.
        }

        // 컨텍스트 액션 모드를 시작한다.
        mActionMode = this.startActionMode( this);
        view.setSelected(true);
        return true;
    }

    // =========================================================
    // ActionMode.Callback 구현
    // =========================================================

    // startActionMode() 호출 시 액션 모드가 생성될 때 호출된다.
    @Override
    public boolean onCreateActionMode(ActionMode mode, Menu menu) {
        // 메뉴 리소스를 팽창(inflate)한다.
        MenuInflater inflater = mode.getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);
        return true;
    }

    // onCreateActionMode() 직후에 호출되며, 메뉴 업데이트에 사용된다.
    @Override
    public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
        return false; // false를 반환하면 아무것도 하지 않은 것이다.
    }

    // 사용자가 컨텍스트 메뉴 항목을 선택하면 호출된다.
    @Override
    public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
        // R.id.end_mode 항목이 선택되었는지 확인합니다.
        if (item.getItemId() == R.id.end_mode) {
            mode.finish(); // 액션이 선택되면 컨텍스트 액션 모드를 닫는다.
            return true;
        }
        else {
            return false;
        }
    }

    // 사용자가 컨텍스트 액션 모드를 빠져나가면 호출된다.
    @Override
    public void onDestroyActionMode(ActionMode mode) {
        mActionMode = null; // mActionMode를 초기화합니다.
    }
}