package com.example.popupmenu;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * XML에서 android:onClick="onClick" 속성으로 지정된 메서드입니다.
     */
    public void onClick(View button) {
        // 1. 팝업 메뉴 객체를 생성합니다. (현재 컨텍스트, 팝업이 표시될 뷰)
        PopupMenu popup = new PopupMenu(this, button);

        // 2. popup.xml 리소스를 팝업 메뉴에 로드합니다.
        popup.getMenuInflater().inflate(R.menu.popup, popup.getMenu());

        // 3. 팝업 메뉴 항목 클릭 리스너를 설정합니다.
        popup.setOnMenuItemClickListener(
                new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {
                        // 팝업 메뉴 항목이 눌러지면 여기서 처리합니다.
                        Toast.makeText(getApplicationContext(),
                                "클릭된 팝업 메뉴: " + item.getTitle(),
                                Toast.LENGTH_SHORT).show();
                        return true;
                    }
                }
        );

        // 4. 팝업 메뉴를 화면에 표시합니다.
        popup.show();
    }
}