package com.example.contextmenu;

import android.graphics.Color;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    TextView text;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // TextView 위젯을 찾습니다.
        text = (TextView) findViewById(R.id.TextView01);

        // 해당 뷰에 컨텍스트 메뉴를 등록합니다.
        registerForContextMenu(text);
    }

    /**
     * 컨텍스트 메뉴를 생성하는 메서드 (뷰를 길게 눌렀을 때 호출)
     */
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        menu.setHeaderTitle("컨텍스트 메뉴");

        // 메뉴 항목을 코드로 동적으로 추가합니다. (itemId: 1, 2, 3)
        // add(int groupId, int itemId, int order, CharSequence title)
        menu.add(0, 1, 0, "배경색: RED");
        menu.add(0, 2, 0, "배경색: GREEN");
        menu.add(0, 3, 0, "배경색: BLUE");
    }

    /**
     * 컨텍스트 메뉴 항목 선택 이벤트를 처리하는 메서드
     */
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        int id = item.getItemId(); // 선택된 메뉴 항목의 ID를 가져옵니다.

        if (id == 1) {
            // ID 1 (RED) 선택 시
            text.setBackgroundColor(Color.RED);
            return true;
        } else if (id == 2) {
            // ID 2 (GREEN) 선택 시
            text.setBackgroundColor(Color.GREEN);
            return true;
        } else if (id == 3) {
            // ID 3 (BLUE) 선택 시
            text.setBackgroundColor(Color.BLUE);
            return true;
        }

        return super.onContextItemSelected(item);
    }
}