package com.example.optionmenu1;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    View view1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        view1 = findViewById(R.id.layout);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId(); // 선택된 메뉴 항목의 ID를 가져옵니다.

        if (itemId == R.id.blue) {
            // '파랑색' 메뉴 항목 선택 시
            view1.setBackgroundColor(Color.BLUE);
            return true;
        } else if (itemId == R.id.green) {
            // '초록색' 메뉴 항목 선택 시
            view1.setBackgroundColor(Color.GREEN);
            return true;
        } else if (itemId == R.id.red) {
            // '빨강색' 메뉴 항목 선택 시
            view1.setBackgroundColor(Color.RED);
            return true;
        }

        // 위에 해당하지 않는 메뉴 항목일 경우 (default 역할)
        return super.onOptionsItemSelected(item);
    }
}
