package com.example.optionmenu2;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        // item1: "사과" 메뉴 항목 추가 (ID: 1)
        MenuItem item1 = menu.add(0, 1, 0, "사과");
        item1.setIcon(R.drawable.ic_launcher_foreground);
        item1.setAlphabeticShortcut('a');

        // item2: "포도" 메뉴 항목 추가 (ID: 2)
        menu.add(0, 2, 0, "포도")
                .setIcon(R.drawable.ic_launcher_foreground);

        // item3: "바나나" 메뉴 항목 추가 (ID: 3)
        menu.add(0, 3, 0, "바나나")
                .setIcon(R.drawable.ic_launcher_foreground);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 1:
                Toast.makeText( this, "사과",
                    Toast.LENGTH_SHORT).show();
                return true;

            case 2:
                Toast.makeText(this,  "포도",
                    Toast.LENGTH_SHORT).show();
                return true;

            case 3:
                Toast.makeText( this,  "바나나",
                    Toast.LENGTH_SHORT).show();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}