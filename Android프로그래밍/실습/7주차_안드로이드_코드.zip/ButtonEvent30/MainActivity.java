package com.example.buttonevent30;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ImageView clothingImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // XML의 뷰들을 ID로 찾아와 변수에 연결
        clothingImageView = findViewById(R.id.clothingImageView);
        Button colorButton1 = findViewById(R.id.colorButton1);
        Button colorButton2 = findViewById(R.id.colorButton2);
        Button colorButton3 = findViewById(R.id.colorButton3);
        Button colorButton4 = findViewById(R.id.colorButton4);

        // 각 버튼에 람다(Lambda)를 사용해 클릭 리스너 설정
        colorButton1.setOnClickListener(view -> changeClothingColor(Color.RED));
        colorButton2.setOnClickListener(view -> changeClothingColor(Color.BLUE));
        colorButton3.setOnClickListener(view -> changeClothingColor(Color.GREEN));
        colorButton4.setOnClickListener(view -> changeClothingColor(Color.YELLOW));
    }

    /**
     * ImageView의 배경색을 변경하는 메서드
     * @param color 변경할 색상 값
     */
    private void changeClothingColor(int color) {
        clothingImageView.setBackgroundColor(color);
    }
}