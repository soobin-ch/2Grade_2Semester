package com.example.survey;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private RadioGroup radioGroupVersions;
    private ImageView imageViewAndroid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // XML 레이아웃의 뷰들과 연결
        radioGroupVersions = findViewById(R.id.radioGroupVersions);
        imageViewAndroid = findViewById(R.id.imageViewAndroid);

        // 라디오 그룹에 리스너 설정
        radioGroupVersions.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // checkedId는 선택된 라디오 버튼의 ID입니다.
                // 이 ID를 사용하여 어떤 버튼이 선택되었는지 확인합니다.


                if (checkedId == R.id.radioButtonGingerbread) {
                    imageViewAndroid.setImageResource(R.drawable.image0);

                }
                if (checkedId == R.id.radioButtonJellyBean) {
                    imageViewAndroid.setImageResource(R.drawable.image1);

                }
                if (checkedId == R.id.radioButtonKitKat) {
                     imageViewAndroid.setImageResource(R.drawable.image2);

                }
            }
        });
    }
}