package com.example.todolist;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextNewTask;
    private Button buttonAddTask;
    private LinearLayout containerTasks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // UI 요소들을 ID로 찾아와 변수에 연결합니다.
        editTextNewTask = findViewById(R.id.editTextNewTask);
        buttonAddTask = findViewById(R.id.buttonAddTask);
        containerTasks = findViewById(R.id.containerTasks);

        // '추가' 버튼에 클릭 리스너를 설정합니다.
        buttonAddTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // EditText에서 사용자가 입력한 텍스트를 가져옵니다.
                String taskText = editTextNewTask.getText().toString().trim();

                // 입력된 텍스트가 비어있지 않은 경우에만 실행합니다.
                if (!taskText.isEmpty()) {
                    // 새로운 체크박스를 생성하고 화면에 추가하는 메서드를 호출합니다.
                    addTask(taskText);
                    // 입력창을 비워 다음 입력을 준비합니다.
                    editTextNewTask.setText("");
                }
            }
        });
    }

    /**
     * 새로운 체크박스를 생성하여 컨테이너 레이아웃에 추가하는 메서드
     *
     * @param taskText 체크박스에 표시될 텍스트
     */
    private void addTask(String taskText) {
        // 1. 새로운 CheckBox 객체를 동적으로 생성합니다.
        CheckBox newCheckBox = new CheckBox(this);

        // 2. 사용자가 입력한 텍스트를 CheckBox의 텍스트로 설정합니다.
        newCheckBox.setText(taskText);

        // (선택사항) 보기 좋게 상하좌우 여백(margin)을 설정할 수 있습니다.
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 16, 0, 16);
        newCheckBox.setLayoutParams(params);

        // 3. 준비된 CheckBox를 컨테이너(LinearLayout)에 추가합니다.
        containerTasks.addView(newCheckBox);
    }
}